package com.alpha.work1;

public class Book {
    private int id;
    private String title;
    private String author;
    private String pulisher;
    private int year;
    private int page;
    private double cost;

        // Task 1-3
    public Book() {}

    public Book(int id, String title, String author) {
        this.id = id;
        this.title = title;
        this.author = author;
    }

    public Book(int id, String title, double cost) {
        this.id = id;
        this.title = title;
        this.cost = cost;
    }


    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public String getPulisher() {
        return pulisher;
    }

    public void setPulisher(String pulisher) {
        this.pulisher = pulisher;
    }

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }

    public int getPage() {
        return page;
    }

    public void setPage(int page) {
        this.page = page;
    }

    public double getCost() {
        return cost;
    }

    public void setCost(double cost) {
        this.cost = cost;
    }

    public void view() {
        System.out.println(getId() + " "
                + this.getTitle() + " "
                + author + " "
                + pulisher + " "
                + year + " "
                + page + " "
                + cost);
    }
}
