package com.alpha.work1;

public class Runner {
    public void run() {
        Book book1 = new Book();
            // Task 1-1
//        System.out.println(book1.getId() + " "
//                        + book1.getTitle() + " "
//                        + book1.getAuthor() + " "
//                        + book1.getPulisher() + " "
//                        + book1.getYear() + " "
//                        + book1.getPage() + " "
//                        + book1.getCost());
            // Task 1-2
        book1.view();
        book1.setId(1);
        book1.setTitle("Black and White");
        book1.setAuthor("John Red");
        book1.setPulisher("DOG");
        book1.setYear(2021);
        book1.view();

            // Task 1-3
        Book book2 = new Book(2, "Animals", "CAT");
        book2.view();
        Book book3 = new Book(3, "Birds", 52.36);
        book3.view();
    }
}
