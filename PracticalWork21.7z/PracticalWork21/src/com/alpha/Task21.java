package com.alpha;

import com.alpha.work1.Runner;

public class Task21 {
    public static void main(String[] args) {
        Runner runner = new Runner();
        runner.run();
    }
}
