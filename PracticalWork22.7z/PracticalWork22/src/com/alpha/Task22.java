package com.alpha;

import com.alpha.work1.Runner;

public class Task22 {

    public static void main(String[] args) {
	    new Runner().run();

	    new com.alpha.work2.Runner().run();

	    new com.alpha.work3.Runner().run();

	    new com.alpha.work4.Runner().run();
    }
}
