package com.alpha.work1;

public class MyCalculate {
    public static double calcPi(int numberElements) {
        double result = 0.0;
        final int NUM = 4;
        double value = 1.0;

        for (int i = 0; i < numberElements; i++) {
            if (i % 2 == 0) {
                result += NUM / value;
            } else {
                result -= NUM / value;
            }
            value += 2;
        }
        return result;
    }
}
