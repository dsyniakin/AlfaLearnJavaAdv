package com.alpha.work2;

public class Runner {
    public void run() {
        Employee employeeOne = new Employee();
        employeeOne.setFirstName("Ben");
        employeeOne.setLastName("Black");
        employeeOne.setOccupation("Doctor");
        employeeOne.setTelephone("38(050) 236-52-57");

        System.out.println("numberOfEmployees " + Employee.getNumberOfEmployees());

        Employee employeeTwo = new Employee();
        employeeTwo.setFirstName("Clara");
        employeeTwo.setLastName("Red");

        System.out.println("numberOfEmployees " + Employee.getNumberOfEmployees());

        Employee employeeThree = new Employee();
        employeeThree.setFirstName("Clara");
        employeeThree.setLastName("Red");
        employeeThree.setTelephone("067451-2654");

        System.out.println("numberOfEmployees " + Employee.getNumberOfEmployees());
    }
}
