package com.alpha.work4;

import com.alpha.work4.calcarea.Calculate;

public class Runner {
    public void run() {
        double scircleOne = Calculate.areaCircle(10);
        int squareOne = Calculate.areaSquare(5);

        System.out.printf("Area circle %.2f %n", scircleOne);
        System.out.println("Area square " + squareOne);

    }
}
