package com.alpha.work4.calcarea;

public class Calculate {
    public static double areaCircle(double r) {
        return 2 * Math.PI * r * r;
    }

    public static int areaSquare(int a) {
        return a * a;
    }

}
