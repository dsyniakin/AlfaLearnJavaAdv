package com.alpha.work3;

import java.util.Random;

public class Id {
    private int id;
    private static int nextId;

    static {
        makeNextId();
    }

    public Id() {
        id = nextId;
        nextId++;
    }

    public int getId() {
        return id;
    }

    public static int getNextId() {
        return nextId;
    }

    private static void makeNextId() {
        nextId = new Random().nextInt(100) + 1;
    }
}
