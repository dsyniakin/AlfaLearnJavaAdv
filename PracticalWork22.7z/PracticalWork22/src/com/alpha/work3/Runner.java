package com.alpha.work3;

public class Runner {
    public void run() {
        Id idOne = new Id();
        System.out.println("idOne " + idOne.getId());

        Id idTwo = new Id();
        System.out.println("idTwo " + idTwo.getId());

        Id idThree = new Id();
        System.out.println("idThree " + idThree.getId());

        System.out.println("nextId " + Id.getNextId());

    }
}
